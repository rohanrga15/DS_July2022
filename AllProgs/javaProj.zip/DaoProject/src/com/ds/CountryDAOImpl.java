package com.ds;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CountryDAOImpl implements CountryDAO {

	Connection conn; //global ref

	public CountryDAOImpl() {
		// TODO Auto-generated constructor stub
		 System.out.println("FindCountryFromDatabaseServlet()");   	
	        try {
				Class.forName("org.hsqldb.jdbc.JDBCDriver");
				System.out.println("Database Driver loaded....");
				conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
			    System.out.println("Connected to the DB : "+conn);	
				  
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	@Override
	public void saveCountry(Country cnt) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement pst = conn.prepareStatement("insert into mycountries values (?,?,?,?,?)");
			pst.setString(1, cnt.getName());
			pst.setString(2, cnt.getCapital());
			pst.setString(3, cnt.getPrimeMinister());
			pst.setString(4, cnt.getPopulation());
			pst.setString(5, cnt.getCurrency());
			int row  = pst.executeUpdate();
			System.out.println("Country created : "+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Country findCountry(String primaryKeyCountryName) {

		Country theCountry = null;

		try {
			Statement st = conn.createStatement();
			System.out.println("statement created.."+st);
			ResultSet rs = st.executeQuery("SELECT * FROM MYCOUNTRIES where countryname='"+primaryKeyCountryName+"'");
			System.out.println("Query fired...got the result...");
			
			
			if(rs.next()) {
				theCountry = new Country();
				theCountry.setName(rs.getString(1));
				theCountry.setCapital (rs.getString(2));
				theCountry.setPrimeMinister ( rs.getString(3));
				theCountry.setPopulation( rs.getString(4));
				theCountry.setCurrency ( rs.getString(5));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return theCountry;
	}

	@Override
	public List<Country> findAllCountries() {
		ArrayList<Country> countryList = new ArrayList();

		try {
			Statement st = conn.createStatement();
			System.out.println("statement created.."+st);
			ResultSet rs = st.executeQuery("SELECT * FROM MYCOUNTRIES");
			System.out.println("Query fired...got the result...");
			
			
			while(rs.next()) {
				Country theCountry = new Country();
				theCountry.setName(rs.getString(1));
				theCountry.setCapital (rs.getString(2));
				theCountry.setPrimeMinister ( rs.getString(3));
				theCountry.setPopulation( rs.getString(4));
				theCountry.setCurrency ( rs.getString(5));
				
				countryList.add(theCountry);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return countryList;
	}

	@Override
	public void modifyCountry(Country cnt) {
		try {
			PreparedStatement pst = conn.prepareStatement("update mycountries set primeminister=?, population=?, currency=? where countryname=?)");
			pst.setString(4, cnt.getName());
			pst.setString(1, cnt.getPrimeMinister());
			pst.setString(2, cnt.getPopulation());
			pst.setString(3, cnt.getCurrency());
			int row  = pst.executeUpdate();
			System.out.println("Country updated : "+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void removeCountry(String primaryKeyCountryName) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement pst = conn.prepareStatement("delete from mycountries where countryname=?)");
			pst.setString(1, primaryKeyCountryName);
			int row  = pst.executeUpdate();
			System.out.println("Country deleted : "+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
