function validateUser() {
		var username = document.getElementById("username").value;

		if (username == "") {
			document.getElementById("user").innerHTML = "Username cannot be blank";
			return false;
		}

		var password = document.getElementById("userpass").value;
		var rpassword = document.getElementById("ruserpass").value;

		if (password == "") {
			document.getElementById("pass").innerHTML = "Password cannot be blank";
			return false;
		}

		let pattern = /@gmail.com$/;
		if (pattern.test(username) == false) {
			document.getElementById("user").innerHTML = "Invalid e-mail";
			return false;
		}

		let pattern2 = /[0-9]/;
		if (pattern2.test(password) == false) {
			document.getElementById("pass").innerHTML = "Password must contain a digit";
			return false;
		}

		let pattern3 = /[a-z]/;
		if (pattern3.test(password) == false) {
			document.getElementById("pass").innerHTML = "Password must contain a capital and small letter";
			return false;
		}

		let pattern4 = /[A-Z]/;
		if (pattern4.test(password) == false) {
			document.getElementById("pass").innerHTML = "Password must contain a capital and small letter";
			return false;
		}

		if (password.length < 8) {
			document.getElementById("pass").innerHTML = "Password must have 8 or more digits";
			return false;
		}

		if (rpassword != password) {
			document.getElementById("rpass").innerHTML = "Password not matching";
			return false;
		} 
		
		else {
			alert('Account created successfully')
			return true;
			
		}
	}

	function clearA() {
		document.getElementById("user").innerHTML = "";
		document.getElementById("pass").innerHTML = "";
		document.getElementById("rpass").innerHTML = "";
	}