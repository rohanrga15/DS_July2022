package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginServlet2")
public class LoginServlet2 extends HttpServlet {

	Connection c;
	
    public LoginServlet2() throws SQLException, ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
        c = DriverManager.getConnection("jdbc:mysql:///mysql", "root", "Oneplus7t");
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter p = response.getWriter();
		response.setContentType("text/html");
		
		PersonalInfo pp = new PersonalInfo("", "", "", "", "", 0); 

		String c1 = request.getParameter("uname");
		String c2 = request.getParameter("upass");
		
		p.println("<br>");
		
		try {
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery("select * from PersonalInfo where pass = '"+c2+"' && user = '"+c1+"'");
			
			
			
			if(rs.next())
			{
				pp.user = rs.getString(1);
				pp.pass = rs.getString(2);
				pp.fname = rs.getString(3);
				pp.lname = rs.getString(4);
				pp.email = rs.getString(5);
				pp.age = rs.getInt(6);
				
				request.setAttribute("perInf", pp);
				
				RequestDispatcher r = request.getRequestDispatcher("Dashboard.jsp");
				r.forward(request, response);
				
			}
			
			else
			{
				p.println("<script>");
				p.println("alert('Wrong username or password')");
				p.println("</script>");
				RequestDispatcher r = request.getRequestDispatcher("login.html");
				r.include(request, response);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
