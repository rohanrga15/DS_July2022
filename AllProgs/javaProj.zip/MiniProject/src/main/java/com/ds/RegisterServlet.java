package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	Connection c;
	
    public RegisterServlet() throws SQLException, ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
        c = DriverManager.getConnection("jdbc:mysql:///mysql", "root", "Oneplus7t");
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter p = response.getWriter();
		response.setContentType("text/html");
		
		PersonalInfo pp = new PersonalInfo("", "", "", "", "", 0); 

		String c1 = request.getParameter("uname");
		String c2 = request.getParameter("upass");
		String c3 = request.getParameter("ufname");
		String c4 = request.getParameter("ulname");
		String c5 = request.getParameter("uemail");
		String ag = request.getParameter("uage");
		int c6 = Integer.parseInt(ag);
		
		p.println("<br>");
		
		try {
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery("select * from PersonalInfo where pass = '"+c2+"' && user = '"+c1+"'");
			
			
			
			if(rs.next())
			{
				p.println("<script>");
				p.println("alert('User already exists')");
				p.println("</script>");
				RequestDispatcher r = request.getRequestDispatcher("login.html");
				r.include(request, response);
			}
			
			else
			{
				PreparedStatement ps = c.prepareStatement("insert into PersonalInfo values(?, ?, ?, ?, ?, ? )");
				
				ps.setString(1, c1);
				ps.setString(2, c2);
				ps.setString(3, c3);
				ps.setString(4, c4);
				ps.setString(5, c5);
				ps.setInt(6, c6);
				
				ps.execute();
				
				p.println("<script>");
				p.println("alert('User successfully registered')");
				p.println("</script>");
				RequestDispatcher r = request.getRequestDispatcher("login.html");
				r.include(request, response);
				
			}
			
		} catch (SQLException e) {
			p.println("<script>");
			p.println("alert('User already exists')");
			p.println("</script>");
			RequestDispatcher r = request.getRequestDispatcher("login.html");
			r.include(request, response);
		}
		

		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
