package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;


@WebServlet("/LoginServlet")
public class LoginServlet extends GenericServlet {

	Connection c;
	
    public LoginServlet() throws SQLException, ClassNotFoundException {
    	
    	Class.forName("com.mysql.jdbc.Driver");
        c = DriverManager.getConnection("jdbc:mysql:///mysql", "root", "Oneplus7t");
        
    }

	public void init(ServletConfig config) throws ServletException {

	}

	public void destroy() {
		
	}

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		PrintWriter p = response.getWriter();
		response.setContentType("text/html");
		
		p.println("<h3>Logging in...</h3>");
		
		String c1 = request.getParameter("uname");
		String c2 = request.getParameter("upass");
		
		p.println(c1);
		p.println(c2);
		
		p.println("<br>");
		
		try {
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery("select * from PersonalInfo where pass = '"+c2+"' && user = '"+c1+"'");
			
			if(rs.next())
			{
				p.println("Logged in");
			}
			
			else
			{
				p.println("Wrong username/password");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
