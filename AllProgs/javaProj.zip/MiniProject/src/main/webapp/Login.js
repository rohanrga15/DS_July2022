function validateUser() {
		var username = document.getElementById("username").value;
		var password = document.getElementById("userpass").value;

		if (username == "") {
			document.getElementById("user").innerHTML = "Username cannot be blank";
			return false;
		}

		if (password == "") {
			document.getElementById("pass").innerHTML = "Password cannot be blank";
			return false;
		}
	}

	function clearA() {
		document.getElementById("user").innerHTML = "";
		document.getElementById("pass").innerHTML = "";
	}
	

	function preventBack() { window.history.forward(); }
	setTimeout("preventBack()", 0);
	window.onunload = function () { null };
