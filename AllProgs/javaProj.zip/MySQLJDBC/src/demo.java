import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class demo 
{
	public static void main(String[] args) throws SQLException {
		
		//Class.forName("com.mysql.jdbc.Driver");
		//Class.forName("org.hsqldb.jdbc.JDBCDriver");
		//DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		System.out.println("Driver loaded...");
		
		String s = "Karnataka";
		
		//Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mdb","root","Oneplus7t");
		Connection con=DriverManager.getConnection("jdbc:mysql:///mysql", "root", "Oneplus7t");
		System.out.println("Connected...");
		
		PreparedStatement ps=con.prepareStatement("select * from state where stateName=?");
		ps.setString(1,s);
		ResultSet rs=ps.executeQuery();
		System.out.println("Query fired..got the result.....");
		
		while(rs.next())
		{
			System.out.print(rs.getString(2)+ " "+rs.getString(3)+ " "+rs.getString(4));
		}
		System.out.println("ResultSet is sent....");
		
		con.close();
		System.out.println("Connection closed.......");
	}
}
