
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SelectMenu 
{
	void selectDatabase(Connection con) throws SQLException 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the person's aadhar");
		int ad = sc.nextInt();
		
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from Person where aadharNo = "+ad);
		
		while(rs.next())
		{
			int i = rs.getInt(3);
			String n = rs.getString(1);
			String c = rs.getString(2);
			
			System.out.println(i);
			System.out.println(n);
			System.out.println(c);
			
			System.out.println();
		}
		
		rs.close();
		st.close();
		con.close();
	}
}