
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteMenu 
{
	void deleteDatabase(Connection con) throws SQLException 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the person's aadhar number");
		int ad = sc.nextInt();
		
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from Person where aadharNo = "+ad);
		
		if(rs.next())
		{
			PreparedStatement p = con.prepareStatement("delete from Person where aadharNo = ?");
			p.setInt(1, ad);
			
			int x = p.executeUpdate();
		}
		
		else
		{
			EmployeeNotFoundException e = new EmployeeNotFoundException();
			throw e;
		}
		
		rs.close();
		st.close();
		con.close();
	}
}