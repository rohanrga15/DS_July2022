
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectAllMenu 
{
	void selectAllDatabase(Connection con) throws SQLException 
	{
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from Person");
		
		while(rs.next())
		{
			int ad = rs.getInt(3);
			String n = rs.getString(1);
			String c = rs.getString(2);
			
			System.out.println("--------");
			System.out.println(ad);
			System.out.println(n);
			System.out.println(c);
		}
		
		rs.close();
		st.close();
		con.close();
	}
}