
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateMenu {
	void updateDatabase(Connection c) throws SQLException, InterruptedException {

		
		PreparedStatement p = c.prepareStatement("update Person set name = ?, city = ? where aadharNo = ?");

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter ad");
		int ad = sc.nextInt();

		Statement s = c.createStatement();
		ResultSet r = s.executeQuery("select * from Person where aadharNo = " + ad);

		if (!r.next()) {
			EmployeeNotFoundException e = new EmployeeNotFoundException();
			throw e;
		}

		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter name");
		String n = sc1.next();

		Scanner sc2 = new Scanner(System.in);
		System.out.println("Enter city");
		String city = sc2.next();

		p.setInt(3, ad);
		p.setString(1, n);
		p.setString(2, city);
		
		int x = p.executeUpdate();
		

		s.close();
		p.close();
		c.close();

	}
}