import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HashMapAssignment {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a city");
		String ci = sc.next();

		CityZipcode c = new CityZipcode(ci);
		c.addRecords();
		c.checkRetreiveRecords();
	}
}

class CityZipcode
{
	Map<String, Integer> m;
	String s;
	int i;
	
	public CityZipcode(String s) 
	{
		super();
		m = new HashMap<String, Integer>();
		this.s = s;
		i = 0;
	}
	
	void addRecords()
	{
		m.put("Bangalore", 560079);
		m.put("Pune", 540372);
		m.put("Dehli", 897745);
		m.put("Punjab", 998757);
		m.put("TamilNadu", 567987);
	}
	
	void checkRetreiveRecords()
	{
		if (m.containsKey(s)) {
			int z = m.get(s);
			System.out.println(z);
		}

		else
		{
			System.out.println("Record not found");
		}
	}
}