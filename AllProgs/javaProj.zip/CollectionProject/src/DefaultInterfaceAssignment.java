
public class DefaultInterfaceAssignment 
{
	public static void main(String[] args) 
	{
		Operations o = new Operations();
		o.add(7, 8);
		o.subtract(8, 54);
		o.multiply(7, 8);
		o.divide(7, 7);
	}
}

interface Calculator
{
	default void calc(int ans)
	{
		System.out.println("The solution is "+ans);
	}
}

class Operations implements Calculator
{
	void add(int a, int b)
	{
		int ans = a+b;
		calc(ans);
	}
	
	void subtract(int a, int b)
	{
		int ans = a-b;
		calc(ans);
	}
	
	void multiply(int a, int b)
	{
		int ans = a*b;
		calc(ans);
	}
	
	void divide(int a, int b)
	{
		int ans = a/b;
		calc(ans);
	}
	
}