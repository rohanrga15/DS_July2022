import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class Company 
{
	public static void main(String[] args) 
	{
		Demo d1 = new Demo();
		d1.show();	
	}
}

class DassaultSystemes
{
	static int ID = 10;
	String name;
	String location;
	int noOfEmployees = 0;
	public DassaultSystemes(String name, String location) 
	{
		super();
		ID = 10;
		this.name = name;
		this.location = location;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		this.ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getNoOfEmployees() {
		return noOfEmployees;
	}
	public void setNoOfEmployees(int noOfEmployees) {
		this.noOfEmployees = noOfEmployees;
	}
	@Override
	public String toString() {
		return "DassaultSystemes [ID=" + ID + ", name=" + name + ", location=" + location + ", noOfEmployees="
				+ noOfEmployees + "]";
	}
}

class Demo
{
	static int a;
	static ArrayList<DassaultSystemes> ar = new ArrayList<DassaultSystemes>();
	
	void show()
	{
		a = a + 10;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Dept name");
		String st1 = sc.next();
		System.out.println("Enter the Location");
		String st2 = sc.next();
	
		DassaultSystemes d1 = new DassaultSystemes(st1, st2);
		d1.setID(a);
		
		Check c1 = new Check();
		c1.a(ar, d1);
		
		System.out.println(d1);
		
		ar.add(d1);
		Iterator<DassaultSystemes> it = ar.iterator();
		
		while(it.hasNext()==true)
		{
			DassaultSystemes log = it.next();
			System.out.println(log);
		}
				
		
		
		Demo2 d = new Demo2();
		d.loop();
	}
}


class Demo2
{
	void loop()
	{
		Demo d = new Demo();
		d.show();
	}
}

class Check
{
	void a(ArrayList<DassaultSystemes> a, DassaultSystemes b)
	{
		InputMismatchException e = new InputMismatchException("Same Dept");
		
		for (DassaultSystemes dassaultSystemes : a) {
			if(dassaultSystemes.equals(b))
				throw e;
			System.out.println("a");
		}
	}
}
/*System.out.println(1);
for (DassaultSystemes dassaultSystemes : ar) {
	
	if(dassaultSystemes.name == d.name)
	{
		InputMismatchException e = new InputMismatchException("Dept already exists");
		throw e;	
	}*/
