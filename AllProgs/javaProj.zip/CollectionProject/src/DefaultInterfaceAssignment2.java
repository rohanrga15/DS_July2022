import java.util.Scanner;

public class DefaultInterfaceAssignment2 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee name");
		String str = sc.next();
		System.out.println("Enter employee number");
		int id = sc.nextInt();
		System.out.println("Enter employee CTC per annum");
		double d = sc.nextInt();
		
		Employee e = new Employee(str, id, d);
		e.empSalary();
		e.idProof();
		
		Person p = new Person();
		p.idProof();
		p.fileITR();
	}
}

interface Citizen
{
	default double tax(double sal)
	{
		if(sal < 250000)
			return 0;
		else if(sal < 500000)
			return (0.05*(sal-250000));
		else if(sal < 1000000)
			return ((0.05*(250000))+(0.15*(sal-500000)));
		else
			return ((0.05*(250000))+(0.15*(500000))+(0.20*(sal-1000000)));
	}
	
	default void vote()
	{
		System.out.println("Voting...");
	}
	
	void idProof();	
	void fileITR();
}

class Employee implements Citizen
{
	String name;
	int empno;
	double salary;
	double tax;
	
	public Employee(String name, int empno, double salary) 
	{
		super();
		this.name = name;
		this.empno = empno;
		this.salary = salary;
		tax = tax(salary);
	}

	void empSalary()
	{
		System.out.println("Employee number : "+empno);
		System.out.println("Employee name : "+name);
		System.out.println("Salary in hand : "+(salary-tax));
	}

	@Override
	public void idProof() 
	{
		System.out.println("ID proof : Passport");	
	}

	@Override
	public void fileITR() {
		System.out.println("Filing IT returns - Paid "+tax+" in tax");
		
	}
}

class Person implements Citizen
{

	@Override
	public void idProof()
	{
		System.out.println("ID proof : Aadhar card");	
	}

	@Override
	public void fileITR() {
		System.out.println("No taxable income");
		
	}
	
}