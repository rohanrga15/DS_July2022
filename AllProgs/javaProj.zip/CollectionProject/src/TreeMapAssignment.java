import java.util.Scanner;
import java.util.TreeMap;

public class TreeMapAssignment 
{
	public static void main(String[] args) 
	{
		TreeMap<Double, String> t = new TreeMap<Double, String>();	
		
		inputRecords(t);
	}
	
	static void add(double d, String srt, TreeMap<Double, String> t)
	{
		
		t.put(d, srt);
		System.out.println("Records : "+t);
		
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println();
		System.out.println("Press 1 to continue");
		System.out.println("Press 2 to stop");
		int a = sc.nextInt();
		
		if(a==1)
		inputRecords(t);
		
		else
		System.out.println("Terminated");
	}
	
	static void inputRecords(TreeMap<Double, String> t)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employee salary");
		double empno = sc.nextInt();
		System.out.println("Enter the employee name");
		String empname = sc.next();
		
		add(empno, empname, t);
	}
}
