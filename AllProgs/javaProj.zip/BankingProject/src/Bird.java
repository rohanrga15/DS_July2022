
public class Bird 
{
	private String name;
	private int age;
	private String type;
	private double dist;
	public Bird(String name) 
	{
		super();
		this.name = name;
	}
	public Bird(String name, int age) 
	{
		super();
		this.name = name;
		this.age = age;
	}
	public Bird(String name, int age, String type) 
	{
		super();
		this.name = name;
		this.age = age;
		this.type = type;
	}
	public Bird(String name, int age, String type, double dist) 
	{
		super();
		this.name = name;
		this.age = age;
		this.type = type;
		this.dist = dist;
	}
	
	public void flying(String type, String dist)
	{
		System.out.println("The bird of "+type+" is flying a distance of "+dist);
	}
	
	public void nesting(String name, int age)
	{
		System.out.println("The "+name+" is nesting in "+age);
	}
}
