
public class DataTypeTest 
{

	public static void main(String[] args) 
	{

		byte b = -128;
		System.out.println("b is "+b);
		System.out.println("max value for a byte is"+Byte.MAX_VALUE);
		System.out.println("min value for a byte is"+Byte.MIN_VALUE);
		System.out.println("size of a byte is"+Byte.SIZE);
		

		short a = 220;
		System.out.println("a is "+a);
		System.out.println("max value for a short is"+Short.MAX_VALUE);
		System.out.println("min value for a shirt is"+Short.MIN_VALUE);
		System.out.println("size of a short is"+Short.SIZE);
				

		int c = 123228;
		System.out.println("c is "+c);
		System.out.println("max value for a int is"+Integer.MAX_VALUE);
		System.out.println("min value for a int is"+Integer.MIN_VALUE);
		System.out.println("size of a int is"+Integer.SIZE);
				

		long d = 13223228;
		System.out.println("d is "+d);
		System.out.println("max value for a long is"+Long.MAX_VALUE);
		System.out.println("min value for a long is"+Long.MIN_VALUE);
		System.out.println("size of a long is"+Long.SIZE);
		

		double e = 3548.778;
		System.out.println("e is "+e);
		System.out.println("max value for a double is"+Double.MAX_VALUE);
		System.out.println("min value for a double is"+Double.MIN_VALUE);
		System.out.println("size of a double is"+Double.SIZE);
		

		float f = 78795.7f;
		System.out.println("f is "+f);
		System.out.println("max value for a float is"+Float.MAX_VALUE);
		System.out.println("min value for a float is"+Float.MIN_VALUE);
		System.out.println("size of a float is"+Float.SIZE);
	}

}
