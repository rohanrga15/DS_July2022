import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class ReflectionTest 
{
	public static void main(String[] args) 
	{
		Bird bird = new Bird("crow");
		
		
		Class tc = bird.getClass();
		Constructor c1[] = tc.getConstructors();
		System.out.println("Constructors : ");
		for (Constructor constructor : c1) {
			System.out.println(constructor);
		}
		System.out.println("----------------");
		
		Method m1[] = tc.getMethods();
		System.out.println("Methods : ");
		
		for (Method method : m1) {
			System.out.println(method);
			
			System.out.println(method.getParameterCount());//store in array
			System.out.println(method.getParameterTypes());//store in array
		}
		
		System.out.println("----------------");
		
		
		
		System.out.println("Methods : ");
		for (Method method : m1) {
			System.out.println(method);
		}
		System.out.println("----------------");
	}
}
