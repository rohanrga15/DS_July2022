
public class StaticSample 
{
	public static void main(String[] args) 
	{
		System.out.println("A is : "+Aa.a);
	}
}

class Aa
{
	static int a = 5;
}