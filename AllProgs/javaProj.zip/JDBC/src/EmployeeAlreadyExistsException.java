
public class EmployeeAlreadyExistsException extends Exception 
{
	EmployeeAlreadyExistsException()
	{
		System.out.println("Employee already exists");
	}
}
