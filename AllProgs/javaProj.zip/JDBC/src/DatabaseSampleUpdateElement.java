import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DatabaseSampleUpdateElement 
{
	public static void main(String[] args) throws EmployeeAlreadyExistsException 
	{
		System.out.println("Registering driver");
		try 
		{
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Registered");
			System.out.println("Trying to connect");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected to "+conn);
			System.out.println("Trying to make a prepared statement");
			PreparedStatement state = conn.prepareStatement("UPDATE EMPLOYEE SET EMPNAME = ? , EMPSAL = ?, EMPNO = ? WHERE EMPNO = ?");
			System.out.println("Prepared statement created"+state);
			
			System.out.println("Enter emp no");
			Scanner s1 = new Scanner(System.in);
			int eno = s1.nextInt();
			
			System.out.println("Enter NEW emp no");
			Scanner s4 = new Scanner(System.in);
			int eno2 = s1.nextInt();
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM EMPLOYEE WHERE EMPNO = "+eno);
			
			if(rs.next())
			{
				
			}
			else
			{
				EmployeeNotFoundException ee = new EmployeeNotFoundException("No emp");
				throw ee;
			}
			
			System.out.println("Enter emp name");
			Scanner s2 = new Scanner(System.in);
			String ename = s1.next();
			
			System.out.println("Enter emp salary");
			Scanner s3 = new Scanner(System.in);
			int sal = s1.nextInt();
			
			
			
			state.setInt(4, eno);
			state.setString(1, ename);	// Integers are referring to the question marks declared in the SQL code
			state.setInt(2, sal);
			state.setInt(3, eno2);
			
			
			int i = state.executeUpdate();
			
//			rs.close();
			state.close();
			conn.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
	}
}

