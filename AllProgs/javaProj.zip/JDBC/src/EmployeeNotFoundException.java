
public class EmployeeNotFoundException extends RuntimeException 
{

	public EmployeeNotFoundException(String str) {
//		super(str);
		System.out.println("Employee not found"+str);
	}
	
}
