import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectTest 
{
	public static void main(String[] args) 
	{
		System.out.println("Registering driver");
		try 
		{
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Registered");
			System.out.println("Trying to connect");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected to "+conn);
			System.out.println("Trying to make a statement");
			Statement state = conn.createStatement();
			System.out.println("Statement created"+state);
			System.out.println("Trying to execute statement");
			ResultSet rs = state.executeQuery("SELECT * FROM EMPLOYEE");
			System.out.println("Statement executed");
			
			while(rs.next())
			{
				int empno = rs.getInt(1);
				String ename = rs.getString(2);
				int sal = rs.getInt(3);
				System.out.println("------------------------");
				System.out.println("Employee number : "+empno);
				System.out.println("Employee name 	: "+ename);
				System.out.println("Employee salary : "+sal);
				System.out.println("------------------------");
			}
			rs.close();
			state.close();
			conn.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
	}
}

