package ds.exceptions;

public class DownloadErrorException extends Exception
{
	public DownloadErrorException(String n) 
	{
		//System.out.println("The error is "+n);
		super(n);
	}
}