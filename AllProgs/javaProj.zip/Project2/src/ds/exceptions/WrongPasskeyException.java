package ds.exceptions;

	public class WrongPasskeyException extends Exception
	{
		public WrongPasskeyException(String n) 
		{
			//System.out.println("The error is "+n);
			super(n);
		}
	}

