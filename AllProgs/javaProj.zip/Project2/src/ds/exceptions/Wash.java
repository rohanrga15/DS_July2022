package ds.exceptions;

public class Wash {

}
