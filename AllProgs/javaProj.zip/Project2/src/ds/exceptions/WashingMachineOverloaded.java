package ds.exceptions;

public class WashingMachineOverloaded extends RuntimeException
{
	public WashingMachineOverloaded(String msg)
	{
		super(msg);
	}
}