package ds.exceptions;

public class WashingMachineIsNotException extends Exception
{
	public WashingMachineIsNotException(String msg)
	{
		super(msg);
	}
}
