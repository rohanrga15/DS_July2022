package ds.exceptions;

public class VirusException extends RuntimeException
{
	public VirusException(String n) 
	{
		//System.out.println("The error is "+n);
		super(n);
	}
}
