
public class InterfaceTestNew 
{
	public static void main(String[] args) 
	{
		
	}
}

class Internet
{}

class Website extends Internet
{}

class Webpage extends Website
{}

class Button 
{}

class Link
{}


