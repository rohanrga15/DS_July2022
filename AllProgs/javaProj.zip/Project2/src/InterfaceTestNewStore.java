
public class InterfaceTestNewStore 
{

}

