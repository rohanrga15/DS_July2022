
public class GenericTest 
{
	public static void main(String[] args) 
	{
		AnyValue<Integer> any = new AnyValue<Integer>(10, 20);
		any.print();
		any.swap();
		any.print();
		
		System.out.println("------------");
		AnyValue<Double> any2 = new AnyValue<Double>(8.56, 7.8);
		any2.print();
		any2.swap();
		any2.print();
		
		System.out.println("------------");
		AnyValue<String> any3 = new AnyValue<String>("John", "Joe");
		any3.print();
		any3.swap();
		any3.print();
		
		Movie m1 = new Movie("Titanic", 1997);
		Movie m2 = new Movie("3 Idiots", 2007);
		
		System.out.println("------------");
		AnyValue<Movie> any4 = new AnyValue<Movie>(m1, m2);
		any4.print();
		any4.swap();
		any4.print();
		
		System.out.println("------------");
	}
}

class AnyValue<T>
{
	T x;
	T y;
	
	AnyValue(T x, T y)
	{
		this.x = x;
		this.y = y;
	}
	
	void print()
	{
		System.out.println(x);
		System.out.println(y);
	}
	
	void swap() 
	{
		System.out.println("Swapping");
		T temp = x;
		x = y;
		y = temp;
		System.out.println("Swapped");
	}
}

class Movie
{
	String name;
	int year;
	public Movie(String name, int year)
	{
		super();
		this.name = name;
		this.year = year;
	}
	@Override
	public String toString() 
	{
		return "Movie [name=" + name + ", year=" + year + "]";
	}
	
}