package Jungle.cave;

public class Tiger 
{
	public void roar()
	{
		System.out.println("Tiger is roaring");
	}
	
	
}
