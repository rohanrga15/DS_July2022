package Jungle.cave;

public class Cave 
{
	void show()
	{	
		Tiger t = new Tiger();
		t.roar();
	}
	
}



