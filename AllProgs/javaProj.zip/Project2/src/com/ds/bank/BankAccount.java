package com.ds.bank;

import java.io.Serializable;

public class BankAccount implements Serializable
{
	private int accNum;
	private String accHol;
	public double balance;
	private int pinNum;
	private static String accType;
	public BankAccount(int accNum, String accHol, double balance, int pinNum) {
		super();
		System.out.println("Bank acc const called");
		this.accNum = accNum;
		this.accHol = accHol;
		this.balance = balance;
		this.pinNum = pinNum;
	}
	@Override
	public String toString() {
		return "BankAccount [accNum=" + accNum + ", accHol=" + accHol + ", balance=" + balance + ", pinNum=" + pinNum
				+ "]";
	}
	
	
}
