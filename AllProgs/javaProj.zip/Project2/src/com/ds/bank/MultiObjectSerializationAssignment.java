package com.ds.bank;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.InputMismatchException;

public class MultiObjectSerializationAssignment 
{
	public static void main(String[] args) throws IOException
	{
		ReadAndWriteDetails w1 = new ReadAndWriteDetails(123456, "James", 20000, 2458);
//		w1.writeFile("C:\\Users\\RGA15\\Desktop\\file.txt");
		
		w1.readFile("C:\\Users\\RGA15\\Desktop\\file.txt");
	}
}

class ReadAndWriteDetails
{
	BankAccount b;
	
	ReadAndWriteDetails(int accNum, String accHol, double balance, int pinNum)
	{
		b = new BankAccount(accNum, accHol,balance , pinNum);
		System.out.println("The BankAccount obj has been created");
	}
	
	void writeFile(String f) throws IOException
	{
		try 
		{
			FileOutputStream file = new FileOutputStream(f);
			System.out.println("FileOutpuStream object created");
			ObjectOutputStream objInp = new ObjectOutputStream(file);
			System.out.println("ObjectOutputStream object created with FileOutpuStream object as argument");
			objInp.writeObject(b);
			System.out.println("Data is written in the file ");
			objInp.close();
			file.close();
			System.out.println("File closed");
		} 
		catch (FileNotFoundException e)
		{
			
			System.out.println("File not found");
		}
		
		catch (IOException e) 
		{
			
			System.out.println("Input exception");
		} 
	}
	
	void readFile(String f)
	{
		try
		{
			BankAccount b = null;
			FileInputStream file = new FileInputStream(f);
			ObjectInputStream objOup = new ObjectInputStream(file);
			b = (BankAccount) objOup.readObject();
			System.out.println(b);
			objOup.close();
			file.close();
		}
		
		catch(InputMismatchException e)
		{
			System.out.println("Input error");
		}
		
		catch(FileNotFoundException e)
		{
			System.out.println("File is not found");
		}
		
		catch(IOException e)
		{
			System.out.println("Input error");
		}
		
		catch(ClassNotFoundException e)
		{
			System.out.println("Class not found");
		}
	
	}
}