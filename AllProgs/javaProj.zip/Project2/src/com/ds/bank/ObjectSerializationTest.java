package com.ds.bank;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectSerializationTest 
{
	public static void main(String[] args) throws IOException 
	{

	BankAccount ba = new BankAccount(123456, "Julie", 203252, 4545);
	System.out.println("ba "+ba.balance);
	
	FileOutputStream fout = new FileOutputStream("C:\\Users\\RGA15\\Desktop\\file.txt");
	
	ObjectOutputStream oo = new ObjectOutputStream(fout);
	
	oo.writeObject(ba);	
	oo.close();
	fout.close();
	
	}
}
	/*public static void main(String[] args) throws IOException 
	{
		BankAccount ba = new BankAccount(123456, "Julie", 203252, 4545);
		System.out.println("ba "+ba.balance);
		
		FileWriter fout = new FileWriter("");
		PrintWriter pw = new PrintWriter(fout);
		
		pw.println(ba.balance);
		
		pw.close();
		fout.close();
	}*/
