package com.ds.bank;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;


public class ObjectDeserializationTest 
{
	public static void main(String[] args) throws IOException, ClassNotFoundException 
	{

	BankAccount ba = null;
	FileInputStream fin = new FileInputStream("C:\\Users\\RGA15\\Desktop\\file.txt");
	ObjectInputStream ois = new ObjectInputStream(fin);
	ba = (BankAccount) ois.readObject();
	
	System.out.println(ba);
	
	ois.close();
	fin.close();
	
	}
}