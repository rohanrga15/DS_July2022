package com.ds;

public class JDBCConnect {

}
