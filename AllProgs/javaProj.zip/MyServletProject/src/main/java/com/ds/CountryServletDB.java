package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.TreeMap;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/country")
public class CountryServletDB extends GenericServlet {
	
	Connection conn;
	
    public CountryServletDB() throws ClassNotFoundException, SQLException {
    	Class.forName("com.mysql.jdbc.Driver");
    	conn = DriverManager.getConnection("jdbc:mysql:///mysql", "root", "Oneplus7t");   	
    }

	public void init(ServletConfig config) throws ServletException {
	}

	public void destroy() {
	}

	
	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		PrintWriter p = response.getWriter();
		response.setContentType("text/html");
		p.println("<h2>Finding country capital</h2>");
		String country = request.getParameter("countryName");
		
		Statement st;
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from country where currency = '"+country+"'");
			
			if(rs.next())
			{String s1 = rs.getString(1);
			String s2 = rs.getString(2);
			String s3 = rs.getString(3);
			
			p.println(s2);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
