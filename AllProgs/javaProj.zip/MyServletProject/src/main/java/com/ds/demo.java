package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.TreeMap;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/demo")
public class demo extends GenericServlet {
	
	Country c1 = new Country("India", "New Dehli", null);
	Country c2 = new Country("China", "Beijing", null);
	Country c3 = new Country("America", "Washington DC", null);
	
	TreeMap<String, Country> t = new TreeMap<String, Country>();
	
    public demo() {
    	t.put("ind", c1);
    	t.put("chi", c2);
    	t.put("usa", c3);
    }

	public void init(ServletConfig config) throws ServletException {
	}

	public void destroy() {
	}

	
	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		PrintWriter p = response.getWriter();
		response.setContentType("text/html");
		p.println("<h2>Finding country</h2>");
		String country = request.getParameter("countryName");
		
		if(t.containsKey(country))
		{	
			Country s = t.get(country);
			p.println("<h5>Capital is "+s+"</h5>");
		}
		else
			p.println("not found");
		
	}

}
