package com.ds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class WelcomeServlet
 */
@WebServlet("/welcome")
public class WelcomeServlet extends GenericServlet {
	
    public WelcomeServlet() {
        System.out.println("Welcome");
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Initializing...");
	}

	
	public void destroy() {
		System.out.println("Reloaded");
	}


	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("service");
		response.setContentType("text/html");
		String hostAd = request.getRemoteAddr();
		int hostPort = request.getRemotePort();
		PrintWriter pw = response.getWriter();
		
		pw.println("<h4>Accessing from address : "+hostAd+" and port "+hostPort+" </h4>");
		
		pw.println("<a href = 'demo1.html'>Back->");
				
	}

}
