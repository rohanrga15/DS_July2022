package com.ds;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ReadWord")
public class ReadWord extends HttpServlet {

    public ReadWord() {

    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("application/msword");
		//response.setContentType("application/vnd.msexcel");
		//response.setContentType("application/vnd.mspowerpoint");
		
		ServletContext cx = getServletContext();
		//InputStream i = cx.getResourceAsStream("C:\\Users\\RGA15\\Downloads\\Sql2.pdf");
		InputStream is = cx.getResourceAsStream("/WEB-INF/data/Dassault_22 days program docx (003).doc");
		//InputStream i = cx.getResourceAsStream("C:/Users/RGA15/Downloads/readPdf.pdf");
		OutputStream o = response.getOutputStream();
		
		int cB = 0;
		byte byteBuff[] = new byte[1024];
		
		while((cB = is.read(byteBuff)) != -1)
		{
			o.write(byteBuff, 0, cB);
		}
		
		o.flush();
		o.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
