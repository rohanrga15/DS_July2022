package com.ds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
   
	public Servlet1() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		
		PrintWriter p = response.getWriter();
		p.println("<h1> 1 </h1>");
		
		Country c = new Country("India", "Rupees", null);
		request.setAttribute("indObj", c);
		
		RequestDispatcher r = request.getRequestDispatcher("/Servlet2");
		r.include(request, response);
		
		p.println("<h2> 1.2 </h2>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
