package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/HeadersEnum")
public class HeadersEnum extends HttpServlet {
        
    public HeadersEnum() {

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter p = response.getWriter();
		
		Enumeration e = request.getHeaderNames();
		
		response.setContentType("text/html");
		
		p.println("<table border = 5px>");
		
		while(e.hasMoreElements())
		{
			String hK = (String)e.nextElement();
			String hV = request.getHeader(hK);
			p.println("<tr>");
			
			p.println("<td>");p.println(hK);p.println("</td>");
			p.println("<td>");p.println(hV);p.println("</td>");
			
			p.println("</tr>");
		}
		
		p.println("</table>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
