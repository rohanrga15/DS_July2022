package com.ds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servlet2")
public class Servlet2 extends HttpServlet {
   
	public Servlet2() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		
		PrintWriter p = response.getWriter();
		p.println("<h1> 2 </h1>");
		
		Country cb = (Country)request.getAttribute("indObj");
		p.println(cb.country);
		
		cb.country = cb.country.toUpperCase();
		
		RequestDispatcher r = request.getRequestDispatcher("/Servlet3");
		r.include(request, response);
		
		p.println("<h2> 2.2 </h2>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
