package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/manageCountry")
public class CountryManagementServlet extends GenericServlet {

	Connection conn;

    public CountryManagementServlet() {
        super();
        System.out.println("FindCountryFromDatabaseServlet()");   	
        try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Database Driver loaded....");
			conn = DriverManager.getConnection("jdbc:mysql:///mysql", "root", "Oneplus7t");
		    System.out.println("Connected to the DB : "+conn);	
			  
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
      
    }

	
	public void init(ServletConfig config) throws ServletException {
	     System.out.println("init");
	}


	public void destroy() {
	     System.out.println("destroy");
	}

	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
	    System.out.println("\t\tservice()");
	    response.setContentType("text/html");
	    
	    ArrayList<Country> a = new ArrayList<Country>();
	    
	    PrintWriter pw = response.getWriter();
	    try {
			Statement st = conn.createStatement();
			System.out.println("statement created.."+st);
			ResultSet rs = st.executeQuery("select * from country");
			System.out.println("Query fired...got the result...");
			
			while(rs.next())
			{
				String s1 = rs.getString(1);
				String s2 = rs.getString(2);
				String s3 = rs.getString(3);
				
				Country c = new Country(s1, s2, s3);
				
				a.add(c);
			}
			
			request.setAttribute("coList", a);
			
			RequestDispatcher r = request.getRequestDispatcher("CountryOP.jsp");
			r.forward(request, response);
			
			rs.close();
			st.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}